Acc = Accessibility = Microsoft Active Accessibility
https://github.com/Descolada/Acc-v2/blob/main/Lib/Acc.ahk
https://learn.microsoft.com/en-us/windows/win32/winauto/microsoft-active-accessibility
https://en.wikipedia.org/wiki/Microsoft_Active_Accessibility

UIA = UI Automation (not UI Access in this case)
https://github.com/Descolada/UIA-v2/blob/main/Lib/UIA.ahk
https://learn.microsoft.com/en-us/windows/win32/winauto/entry-uiauto-win32
https://en.wikipedia.org/wiki/Microsoft_UI_Automation

COM APIs
https://autohotkey.wiki/guides:com:start




as of 26-09-23 I haven't used any of this in an AHK script yet that I actively use, but might be useful someday
I only got this to work: Tabs Outliner UIA Scroll Test.ahk


can use by adding:
#Include <Acc>
#Include <UIA>